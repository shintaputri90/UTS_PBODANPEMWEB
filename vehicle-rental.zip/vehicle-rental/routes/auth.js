const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../config/db');

// Middleware untuk memeriksa apakah pengguna sudah login
function isAuthenticated(req, res, next) {
    if (req.isAuthenticated()) {
        return next();
    }
    res.redirect('/login');
}

// Halaman login
router.get('/login', (req, res) => {
    res.render('login');
});

// Proses login
router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const user = await db.getUserByUsername(username); // Ambil pengguna dari database

    if (user && bcrypt.compareSync(password, user.password)) {
        req.session.userId = user.id; // Simpan user ID ke sesi
        req.flash('success', 'Login successful');
        return res.redirect('/dashboard'); // Redirect ke halaman dashboard
    }

    req.flash('error', 'Invalid username or password');
    res.redirect('/login');
});

// Halaman registrasi
router.get('/register', (req, res) => {
    res.render('register');
});

// Proses registrasi
router.post('/register', async (req, res) => {
    const { username, password } = req.body;
    const hashedPassword = bcrypt.hashSync(password, 10); // Hash password

    try {
        await db.createUser({ username, password: hashedPassword }); // Simpan pengguna ke database
        req.flash('success', 'Registration successful, please log in');
        res.redirect('/login');
    } catch (error) {
        req.flash('error', 'Registration failed, please try again');
        res.redirect('/register');
    }
});

// Logout
router.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.redirect('/dashboard');
        }
        res.redirect('/'); 
    });
});

module.exports = router;
