const express = require('express');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const db = require('./db');
const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

app.use(session({
    secret: 'secret_key',
    resave: false,
    saveUninitialized: true
}));

// Landing Page
app.get('/', (req, res) => res.render('landing'));

// Register Page
app.get('/register', (req, res) => res.render('register'));

app.post('/register', (req, res) => {
    const { username, password } = req.body;
    const hashedPassword = bcrypt.hashSync(password, 10);
    db.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, hashedPassword], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.redirect('/login');
    });
});

// Login Page
app.get('/login', (req, res) => res.render('login'));

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    db.query('SELECT * FROM users WHERE username = ?', [username], (err, result) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        if (result.length && bcrypt.compareSync(password, result[0].password)) {
            req.session.userId = result[0].id;
            res.redirect('/dashboard');
        } else {
            res.redirect('/login');
        }
    });
});

// Dashboard
app.get('/dashboard', (req, res) => {
    if (!req.session.userId) return res.redirect('/login');
    res.render('dashboard');
});

// CRUD Kendaraan
app.get('/kendaraan', (req, res) => {
    db.query('SELECT * FROM kendaraan', (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.render('dataKendaraan', { data: results });
    });
});

app.post('/kendaraan/add', (req, res) => {
    const { nama, tipe, plat } = req.body;
    db.query('INSERT INTO kendaraan (nama, tipe, plat) VALUES (?, ?, ?)', [nama, tipe, plat], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.redirect('/kendaraan');
    });
});

app.post('/kendaraan/edit/:id', (req, res) => {
    const { id } = req.params;
    const { nama, tipe, plat } = req.body;
    db.query('UPDATE kendaraan SET nama = ?, tipe = ?, plat = ? WHERE id = ?', [nama, tipe, plat, id], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.redirect('/kendaraan');
    });
});

app.get('/kendaraan/delete/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM kendaraan WHERE id = ?', [id], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.redirect('/kendaraan');
    });
});

// CRUD Pelanggan
app.get('/pelanggan', (req, res) => {
    db.query('SELECT * FROM pelanggan', (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.render('dataPelanggan', { data: results });
    });
});

app.post('/pelanggan/add', (req, res) => {
    const { nama, kontak } = req.body;
    db.query('INSERT INTO pelanggan (nama, kontak) VALUES (?, ?)', [nama, kontak], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.redirect('/pelanggan');
    });
});

app.post('/pelanggan/edit/:id', (req, res) => {
    const { id } = req.params;
    const { nama, kontak } = req.body;
    db.query('UPDATE pelanggan SET nama = ?, kontak = ? WHERE id = ?', [nama, kontak, id], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.redirect('/pelanggan');
    });
});

app.get('/pelanggan/delete/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM pelanggan WHERE id = ?', [id], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.redirect('/pelanggan');
    });
});

// CRUD Peminjaman
app.get('/peminjaman', (req, res) => {
    db.query('SELECT * FROM peminjaman', (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.render('dataPeminjaman', { data: results });
    });
});

app.post('/peminjaman/add', (req, res) => {
    const { kendaraan_id, pelanggan_id, tanggal_peminjaman } = req.body;
    db.query('INSERT INTO peminjaman (kendaraan_id, pelanggan_id, tanggal_peminjaman) VALUES (?, ?, ?)', [kendaraan_id, pelanggan_id, tanggal_peminjaman], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.redirect('/peminjaman');
    });
});

app.post('/peminjaman/edit/:id', (req, res) => {
    const { id } = req.params;
    const { kendaraan_id, pelanggan_id, tanggal_peminjaman } = req.body;
    db.query('UPDATE peminjaman SET kendaraan_id = ?, pelanggan_id = ?, tanggal_peminjaman = ? WHERE id = ?', [kendaraan_id, pelanggan_id, tanggal_peminjaman, id], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.redirect('/peminjaman');
    });
});

app.get('/peminjaman/delete/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM peminjaman WHERE id = ?', [id], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.redirect('/peminjaman');
    });
});

// CRUD Pengembalian
app.get('/pengembalian', (req, res) => {
    db.query('SELECT * FROM pengembalian', (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.render('dataPengembalian', { data: results });
    });
});

app.post('/pengembalian/add', (req, res) => {
    const { peminjaman_id, tanggal_pengembalian } = req.body;
    db.query('INSERT INTO pengembalian (peminjaman_id, tanggal_pengembalian) VALUES (?, ?)', [peminjaman_id, tanggal_pengembalian], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.redirect('/pengembalian');
    });
});

app.get('/pengembalian/edit/:id', (req, res) => {
    const { id } = req.params;
    db.query('SELECT * FROM pengembalian WHERE id = ?', [id], (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        if (results.length > 0) {
            res.render('dataPengembalian', { editMode: true, pengembalian: results[0] });
        } else {
            res.redirect('/pengembalian');
        }
    });
});

app.get('/pengembalian/delete/:id', (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM pengembalian WHERE id = ?', [id], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send('Database error');
        }
        res.redirect('/pengembalian');
    });
});

// Start Server
const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
